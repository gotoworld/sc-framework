spring-cloud-demo
==========================================
        关于Spring Cloud一些开箱即用工具使用体会。

spring cloud config
------------------------------------------
        spring cloud config 使用本地或者git远程地址方式统一管理项目的各种配置信息。其中服务端，用于配置管理和发布；客户端，引用相关配置地址；
### Server端
        maven依赖如下：
        <dependency>
	        <groupId>org.springframework.cloud</groupId>
	        <artifactId>spring-cloud-config-server</artifactId>
        </dependency>

bootstrap.yml配置文件：
server: 
  port: 8888
  
spring: 
  application: 
    name: configserver
  cloud: 
    config: 
      server: 
        git: 
          uri: https://git.oschina.net/airball/spring-cloud-demo
          searchPaths: cloud-config-repo

git仓库文件如下：
cloud-config-test.yml
cloud-config-dev.yml

服务启动后，访问规则，http://localhost:8888/{application}/{profile}[/{label}]
可通过http://localhost:8888/cloud-config/test或者http://localhost:8888/cloud-config/dev查看配置信息。

客户端：
maven依赖如下：
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-web</artifactId>
</dependency>
	<dependency>
	<groupId>org.springframework.cloud</groupId>
	<artifactId>spring-cloud-starter-config</artifactId>
</dependency>

bootstrap.yml配置文件：
spring:  
  http:
    encoding.charset: UTF-8
  cloud: 
    config:  
      uri: http://127.0.0.1:${config.port:8888}
      name: cloud-config
      profile: ${config.profile:test}
